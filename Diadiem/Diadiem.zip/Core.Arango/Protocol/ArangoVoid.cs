﻿namespace Core.Arango.Protocol
{
    /// <summary>
    ///     Something to deserialize to when no response needed
    /// </summary>
    public class ArangoVoid
    {
    }
}