﻿namespace Core.Arango.Protocol.Internal
{
    internal class ErrorResponse : ArangoResponseBase
    {
    }
}