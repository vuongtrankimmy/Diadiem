﻿namespace Core.Arango.Linq.Query.Clause
{
    internal class SelectModificationClause
    {
    }
}