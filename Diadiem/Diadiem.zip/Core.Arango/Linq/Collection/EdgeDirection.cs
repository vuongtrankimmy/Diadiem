﻿namespace Core.Arango.Linq.Collection
{
    public enum EdgeDirection
    {
        Any = 0,
        Inbound = 1,
        Outbound = 2
    }
}