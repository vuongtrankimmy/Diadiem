﻿namespace Core.Arango.Linq.Interface
{
    public enum NamingConvention
    {
        UnChanged = 0,
        ToCamelCase = 1
    }
}