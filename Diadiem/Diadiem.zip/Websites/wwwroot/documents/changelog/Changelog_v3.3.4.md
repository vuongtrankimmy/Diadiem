﻿# Địa Điểm API v3.3.4


### Cập nhật

## ``FRONTEND USER *[27/06/2020]* v3.3.4``
• **Receipts Cashiers**: In hóa đơn sau khi thanh toán.

 
   • Tùy chỉnh hiển thị phiếu in hóa đơn theo người sử dụng

api/Receipts/Cashiers
``` json
 {
      "LogoDigital": "http://images.diadiem.vn/Users/Images/Customer/438227755/location/logo/location-425242098/200_200/location-425242098-digital.webp",
      "LogoPrinted": "http://images.diadiem.vn/Users/Images/Customer/438227755/location/logo/location-425242098/200_200/location-425242098-printed.webp",
      "DigitalReceipt": "#3b5998",
      "ShowItemDescription": 0,
      "LocationBusinessName": "Pendogo 1",
      "ShowLocation": 0,
      "Contact_Phone": "0123456789",
      "Contact_Facebook": "",
      "Contact_Instagram": "",
      "Contact_Twitter": "",
      "Contact_Website": "",
      "AdditionalText_ReturnPolicy": "",
      "AdditionalText_CustomText": "",
      "ShowReferralBanner": 0
    }
```
