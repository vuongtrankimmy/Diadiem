﻿# Địa Điểm API v1.1


### Cập nhật

## ``Frontend User *[20/01/2020]*``


* **Add: Employee,FloorTable**   
    1. Thêm thông tin đăng nhập nhân viên bằng `PassCode`.
    2. Thêm thông tin thiết lập bàn hỗ trợ cho POS



## ``POS UI *[21/02/2020]*``
* **Update: TimeZone**  
    1. Cập nhập lỗi định dạng TimeZone.
    2. Thêm thời gian hiện tại trên server trả về theo TimeZone.
    3. Định dạng ngày tháng và giờ hiển thị theo TimeZone.
