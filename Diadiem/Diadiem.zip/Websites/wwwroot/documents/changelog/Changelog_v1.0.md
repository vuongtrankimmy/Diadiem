﻿# Địa Điểm API v1.0


### Cập nhật

## ``POS UI *[20/10/2019]*``

* **Region: Danh sách Region**   
Thêm API để kiểm và lấy dữ liệu Region theo `LCID`, `Name`, `TwoLetterISOLanguageName`, `ThreeLetterISOLanguageName`, `RegionNativeName`, `NumericCode`, `RegionGeoId`.

* **TimeZone: Cập nhật**  
Hiển thị Timezone theo `TimeZoneId`.

* **UI: Cập nhật**  
Hiện thị UI đúng theo Formatter JSON và Hiển thị dữ liệu theo ngôn ngữ user sử dụng.
